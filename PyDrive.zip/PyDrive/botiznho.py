import telebot
from pydrive.auth import GoogleAuth
from pydrive.drive import GoogleDrive
import tkinter as tk
from tkinter import filedialog

root = tk.Tk()
root.withdraw()
class DriverController:
        def __init__(self):
                print('iniciado!')
        def __init(self):
                self.gauth = GoogleAuth()
                # Try to load saved client credentials
                self.gauth.LoadCredentialsFile("creds.txt")
                if self.gauth.credentials is None:
                        # Authenticate if they're not there
                        self.gauth.LocalWebserverAuth()
                elif self.gauth.access_token_expired:
                        # Refresh them if expired
                        self.gauth.Refresh()
                else:
                        # Initialize the saved creds
                        self.gauth.Authorize()
                # Save the current credentials to a file
                self.gauth.SaveCredentialsFile("creds.txt")
                # gauth = GoogleAuth()
                # gauth.LocalWebserverAuth()
                self.drive = GoogleDrive(self.gauth)
                pass
        def sendFile(self, file):
                self.__init()
                file1 = self.drive.CreateFile()
                file1.SetContentFile(file)
                file1.Upload()

driver = DriverController()


bot = telebot.TeleBot( "713139444:AAFbFc2lDX5ZTI8ocCBM-1Blfc1Dfpfyxs0" )

@bot.message_handler(commands=['start', 'help'])
def send_start(msg):
    bot.send_message(msg.chat.id , "Bem Vindo !")


@bot.message_handler(content_types=['photo'])
def photo(message):
    print('Recebendo Foto')
    print ('message.photo =', message.photo)
    fileID = message.photo[-1].file_id
    print ('fileID =', fileID)
    file_info = bot.get_file(fileID)
    print('file.file_path =', file_info.file_path)
    downloaded_file = bot.download_file(file_info.file_path)
    with open("image.jpg", 'wb') as new_file:
        new_file.write(downloaded_file)
    driver.sendFile("./image.jpg")
    

# @bot.message_handler(content_types=['video'])
# def photo(message):
#     print('Recebendo Video')
#     file_info = bot.get_file(message.video.file_id)
#     downloaded_file = bot.download_file(file_info.file_path)

#     with open('video.mp4', 'wb') as new_file:
#         new_file.write(downloaded_file)


@bot.message_handler(content_types=['document'])
def handle_docs_photo(message):
    print('Recebendo Documento')
    file_info = bot.get_file(message.document.file_id)
    downloaded_file = bot.download_file(file_info.file_path)
    src=message.document.file_name
    with open(src, 'wb') as new_file:
        new_file.write(downloaded_file)

print("Bot Funcionando !")
bot.polling(none_stop=True, interval=0, timeout=20)